/** layui-v0.1.5 跨设备模块化前端框架@LGPL www.layui.com By 贤心 */
;layui.define("jquery",function(e){layui.jquery;e("slide",{})});